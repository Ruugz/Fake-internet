# Fake Internet
Membuat Android menganggap Wi-Fi "punya internet" (tervalidasi) walau tanpa internet sungguhan,
untuk menguji aplikasi buatan sendiri. Dilengkapi bubble pop-up ON/OFF di atas aplikasi lain.

Build: push ke GitHub -> tab Actions -> unduh artifact FakeInternet-debug (APK).
