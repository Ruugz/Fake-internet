package com.ruugz.fakeinternet

import android.app.Service
import android.content.Intent
import android.os.IBinder
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/** Server HTTP mini: membalas semua request dengan 204 No Content. */
class FakeServerService : Service() {
    companion object {
        const val PORT = 8204
        @Volatile var running = false
    }

    private var server: ServerSocket? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, Notif.build(this, "Server 204 aktif di port $PORT"))
        if (!running) {
            running = true
            thread(isDaemon = true) { runServer() }
        }
        return START_STICKY
    }

    private fun runServer() {
        try {
            val s = ServerSocket()
            s.reuseAddress = true
            s.bind(InetSocketAddress(PORT))
            server = s
            while (running) {
                val c = s.accept()
                thread(isDaemon = true) { handle(c) }
            }
        } catch (_: Exception) {
        } finally {
            running = false
        }
    }

    private fun handle(c: Socket) {
        c.use {
            try {
                it.soTimeout = 3000
                val r = it.getInputStream().bufferedReader()
                while (true) {
                    val line = r.readLine() ?: break
                    if (line.isEmpty()) break
                }
                val out = it.getOutputStream()
                out.write(
                    "HTTP/1.1 204 No Content\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
                        .toByteArray()
                )
                out.flush()
            } catch (_: Exception) {
            }
        }
    }

    override fun onDestroy() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
