package com.ruugz.fakeinternet

import android.content.Context
import android.content.Intent

object FakeControl {
    fun host(ctx: Context): String =
        ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("host", "127.0.0.1")!!

    fun setHost(ctx: Context, h: String) {
        ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putString("host", h).apply()
    }

    /** Jalankan server 204 + arahkan pengaturan sistem. Return false jika izin belum ada. */
    fun enable(ctx: Context): Boolean {
        ctx.startForegroundService(Intent(ctx, FakeServerService::class.java))
        return CaptiveSettings.apply(ctx, host(ctx), FakeServerService.PORT)
    }

    /** Hentikan server + kembalikan pengaturan asli. */
    fun disable(ctx: Context): Boolean {
        ctx.stopService(Intent(ctx, FakeServerService::class.java))
        return CaptiveSettings.reset(ctx)
    }
}
