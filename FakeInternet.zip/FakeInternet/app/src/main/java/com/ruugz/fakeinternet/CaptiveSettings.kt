package com.ruugz.fakeinternet

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

/** Mengarahkan cek konektivitas sistem (captive portal) ke server 204 lokal. */
object CaptiveSettings {
    private val KEYS = listOf(
        "captive_portal_mode",
        "captive_portal_use_https",
        "captive_portal_http_url",
        "captive_portal_https_url",
        "captive_portal_fallback_url",
        "captive_portal_other_fallback_urls"
    )

    fun canWrite(ctx: Context): Boolean =
        ctx.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") ==
            PackageManager.PERMISSION_GRANTED

    fun apply(ctx: Context, host: String, port: Int): Boolean {
        if (!canWrite(ctx)) return false
        val r = ctx.contentResolver
        val p = ctx.getSharedPreferences("backup", Context.MODE_PRIVATE)
        return try {
            if (!p.getBoolean("saved", false)) {
                val e = p.edit()
                KEYS.forEach { e.putString(it, Settings.Global.getString(r, it)) }
                e.putBoolean("saved", true).apply()
            }
            val url = "http://$host:$port/generate_204"
            Settings.Global.putString(r, "captive_portal_mode", "1")
            Settings.Global.putString(r, "captive_portal_use_https", "0")
            Settings.Global.putString(r, "captive_portal_http_url", url)
            Settings.Global.putString(r, "captive_portal_https_url", url)
            Settings.Global.putString(r, "captive_portal_fallback_url", url)
            Settings.Global.putString(r, "captive_portal_other_fallback_urls", url)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun reset(ctx: Context): Boolean {
        if (!canWrite(ctx)) return false
        val p = ctx.getSharedPreferences("backup", Context.MODE_PRIVATE)
        if (!p.getBoolean("saved", false)) return true
        return try {
            val r = ctx.contentResolver
            KEYS.forEach { Settings.Global.putString(r, it, p.getString(it, null)) }
            p.edit().clear().apply()
            true
        } catch (e: Exception) {
            false
        }
    }
}
